/**
 * TEMPLATES.JS — Premium AI Website Builder Templates
 * Each template has a dramatically different personality:
 * - Unique color palette (no two look alike)
 * - Specific font that matches the brand
 * - Matching section variants and content tone
 */

export const TEMPLATES = [
    // ─────────────────────────────────────────────
    // 1. CLEAN MINIMALIST — White / Black / Charcoal
    //    Font: Playfair Display (editorial elegance)
    // ─────────────────────────────────────────────
    {
        id: "modern-minimalist",
        name: "Ivory Editorial",
        description: "Ultra-clean white canvas with editorial serif type and generous whitespace. Works for any brand.",
        themeSelected: "Light",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "Minimal",
                    links: ["Work", "Studio", "Journal", "Contact"],
                    variant: "Minimal Transparent",
                    bgColor: "#ffffff",
                    textColor: "#0f0f0f",
                    accentColor: "#0f0f0f",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "Less is more.",
                    subheading: "We build digital experiences that are intuitive, beautiful, and completely purposeful.",
                    ctaText: "View Our Work",
                    variant: "Split Text Left",
                    bgColor: "#ffffff",
                    textColor: "#0f0f0f",
                    accentColor: "#0f0f0f",
                    fontFamily: "Playfair Display",
                    backgroundImageQuery: "architecture",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Design Philosophy",
                    description: "Our approach strips away the unnecessary, leaving only what is essential. Every decision serves a purpose — every pixel earns its place.",
                    variant: "Left Aligned Big",
                    bgColor: "#f5f5f0",
                    textColor: "#0f0f0f",
                    accentColor: "#0f0f0f",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Selected Works",
                    items: [
                        { title: "Brand Identity", description: "Complete visual identity for a fintech startup.", imageQuery: "design" },
                        { title: "Digital Product", description: "SaaS dashboard with seamless UX.", imageQuery: "laptop" },
                        { title: "Web Platform", description: "End-to-end web experience for a creative agency.", imageQuery: "creative" },
                        { title: "Print Design", description: "Sophisticated print collateral and packaging.", imageQuery: "studio" },
                    ],
                    variant: "Modern Grid",
                    bgColor: "#ffffff",
                    textColor: "#0f0f0f",
                    accentColor: "#0f0f0f",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Let's create something extraordinary.",
                    subheading: "We take on a limited number of projects each quarter.",
                    ctaText: "Start a Project",
                    ctaLink: "#contact",
                    variant: "Centered Large",
                    bgColor: "#f5f5f0",
                    textColor: "#0f0f0f",
                    accentColor: "#0f0f0f",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 Minimal Studio. All rights reserved.",
                    variant: "Ultra Minimal",
                    bgColor: "#0f0f0f",
                    textColor: "#888888",
                    accentColor: "#ffffff",
                    fontFamily: "Playfair Display",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 2. VIBRANT SaaS — Fuchsia / Violet / Dark Navy
    //    Font: Outfit (modern, rounded, tech-friendly)
    // ─────────────────────────────────────────────
    {
        id: "vibrant-playful",
        name: "Neon Pop",
        description: "Bold, energetic dark theme with vivid magenta-violet accents. Great for any modern brand.",
        themeSelected: "Dark",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "Spark",
                    links: ["Features", "Pricing", "Community", "Blog"],
                    variant: "Glassy Island",
                    bgColor: "#0e0e1a",
                    textColor: "#ffffff",
                    accentColor: "#d946ef",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "Make it pop!",
                    subheading: "Unleash your creativity with tools that are as fun to use as they are powerful.",
                    ctaText: "Start Creating Free",
                    ctaLink: "#signup",
                    variant: "Split Text Left",
                    bgColor: "#0e0e1a",
                    textColor: "#ffffff",
                    accentColor: "#d946ef",
                    fontFamily: "Outfit",
                    backgroundImageQuery: "software",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Why Choose Spark?",
                    description: "Because building software shouldn't feel like a chore. We've built a platform that sparks creativity and makes shipping fast.",
                    variant: "Card Based",
                    bgColor: "#12121e",
                    textColor: "#ffffff",
                    accentColor: "#d946ef",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Everything You Need",
                    items: [
                        { title: "Magic Canvas", description: "Real-time collaborative design tools built for speed.", imageQuery: "code" },
                        { title: "Cloud Sync", description: "Instant sync across all your devices, always.", imageQuery: "tech" },
                        { title: "Collab Hub", description: "Invite your team and build together in real time.", imageQuery: "team" },
                        { title: "Instant Share", description: "One-click publish to anywhere on the web.", imageQuery: "startup" },
                        { title: "AI Assistant", description: "Smart suggestions powered by cutting-edge AI.", imageQuery: "software" },
                        { title: "Analytics", description: "Understand your audience with beautiful insights.", imageQuery: "developer" },
                    ],
                    variant: "Bento Grid",
                    bgColor: "#0e0e1a",
                    textColor: "#ffffff",
                    accentColor: "#d946ef",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Ready to jump in?",
                    subheading: "Join over 50,000 creators already using Spark.",
                    ctaText: "Sign Up Free",
                    ctaLink: "#signup",
                    variant: "Floating Pill",
                    bgColor: "#0e0e1a",
                    textColor: "#ffffff",
                    accentColor: "#d946ef",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 Spark App. Built with joy.",
                    variant: "Multi-Column Mock",
                    bgColor: "#08080f",
                    textColor: "#6b6b80",
                    accentColor: "#d946ef",
                    fontFamily: "Outfit",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 3. WEB3 / CRYPTO — Near-Black / Electric Blue
    //    Font: Syne (geometric, futuristic)
    // ─────────────────────────────────────────────
    {
        id: "sleek-dark-mode",
        name: "Midnight Cobalt",
        description: "Sleek deep near-black with electric blue accents — modern and high-tech for any use.",
        themeSelected: "Dark",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "Vortex",
                    links: ["Ecosystem", "Developers", "Network", "Docs"],
                    variant: "Full Width Solid",
                    bgColor: "#050811",
                    textColor: "#ffffff",
                    accentColor: "#2563eb",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "The Future of Web3",
                    subheading: "Constructing decentralized ecosystems with zero compromises on performance or security.",
                    ctaText: "Deploy Now",
                    ctaLink: "#deploy",
                    variant: "Split Text Left",
                    bgColor: "#050811",
                    textColor: "#ffffff",
                    accentColor: "#2563eb",
                    fontFamily: "Outfit",
                    backgroundImageQuery: "abstract",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Core Network Features",
                    items: [
                        { title: "Lightning Fast", description: "Sub-millisecond transaction finality at scale.", imageQuery: "software" },
                        { title: "Ultra Secure", description: "Military-grade cryptography protecting every node.", imageQuery: "tech" },
                        { title: "Decentralized", description: "No single point of failure across 10,000+ nodes.", imageQuery: "code" },
                        { title: "Carbon Neutral", description: "Proof-of-stake. Zero carbon footprint.", imageQuery: "nature" },
                        { title: "Open Source", description: "Fully open codebase with 1,400+ contributors.", imageQuery: "developer" },
                        { title: "Developer First", description: "Best-in-class SDK, APIs, and documentation.", imageQuery: "workspace" },
                    ],
                    variant: "Modern Grid",
                    bgColor: "#050811",
                    textColor: "#ffffff",
                    accentColor: "#2563eb",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Scale globally, instantly.",
                    description: "Deploy your smart contracts to a network designed for planetary scale. 100,000 TPS. 99.99% uptime. Zero compromise.",
                    variant: "Card Based",
                    bgColor: "#080c1a",
                    textColor: "#ffffff",
                    accentColor: "#2563eb",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Start building on Vortex",
                    subheading: "Read our technical whitepaper or jump straight into the developer docs.",
                    ctaText: "View Documentation",
                    ctaLink: "#docs",
                    variant: "Dark Banner",
                    bgColor: "#050811",
                    textColor: "#ffffff",
                    accentColor: "#2563eb",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 Vortex Network.",
                    variant: "Multi-Column Mock",
                    bgColor: "#020508",
                    textColor: "#4b5563",
                    accentColor: "#2563eb",
                    fontFamily: "Outfit",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 4. ELEGANT CORPORATE — Cream / Forest Green
    //    Font: Playfair Display (authoritative, premium)
    // ─────────────────────────────────────────────
    {
        id: "elegant-corporate",
        name: "Forest Heritage",
        description: "Refined cream-and-forest-green palette with classic serif elegance. Polished and timeless.",
        themeSelected: "Light",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "NexusFirm",
                    links: ["Services", "Insights", "Team", "Contact"],
                    variant: "Full Width Solid",
                    bgColor: "#fafaf7",
                    textColor: "#1a2e1a",
                    accentColor: "#166534",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "Strategic Excellence.",
                    subheading: "Delivering world-class financial and legal advisory to Fortune 500 enterprises since 1998.",
                    ctaText: "Our Services",
                    ctaLink: "#services",
                    variant: "Split Text Right",
                    bgColor: "#fafaf7",
                    textColor: "#1a2e1a",
                    accentColor: "#166534",
                    fontFamily: "Playfair Display",
                    backgroundImageQuery: "corporate",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Decades of Expertise",
                    description: "Our partners bring unparalleled expertise across global markets. With a proven track record and deep industry relationships, we navigate complexity to deliver results.",
                    variant: "Left Aligned Big",
                    bgColor: "#ffffff",
                    textColor: "#1a2e1a",
                    accentColor: "#166534",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Practice Areas",
                    items: [
                        { title: "Mergers & Acquisitions", description: "Strategic M&A advisory for transformative deals.", imageQuery: "meeting" },
                        { title: "Corporate Restructuring", description: "Operational restructuring for sustainable growth.", imageQuery: "business" },
                        { title: "Private Equity", description: "Deploying capital into high-growth opportunities.", imageQuery: "finance" },
                        { title: "Risk Management", description: "Comprehensive risk frameworks to protect assets.", imageQuery: "office" },
                    ],
                    variant: "Modern Grid",
                    bgColor: "#f4f4ef",
                    textColor: "#1a2e1a",
                    accentColor: "#166534",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Ready to work together?",
                    subheading: "Schedule a confidential consultation with one of our senior partners.",
                    ctaText: "Request Consultation",
                    ctaLink: "#contact",
                    variant: "Split Screen CTA",
                    bgColor: "#ffffff",
                    textColor: "#1a2e1a",
                    accentColor: "#166534",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "ContactForm",
                props: {
                    heading: "Request a Consultation",
                    fields: ["name", "email", "company", "phone", "message"],
                    variant: "Left Text Right Form",
                    bgColor: "#fafaf7",
                    textColor: "#1a2e1a",
                    accentColor: "#166534",
                    fontFamily: "Playfair Display",
                    submitText: "Request Consultation",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 Nexus Advisory Firm LLC.",
                    variant: "Multi-Column Mock",
                    bgColor: "#1a2e1a",
                    textColor: "#6b8f6b",
                    accentColor: "#4ade80",
                    fontFamily: "Playfair Display",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 5. BOLD CREATIVE AGENCY — Jet Black / Electric Orange
    //    Font: Outfit (expressive, powerful)
    // ─────────────────────────────────────────────
    {
        id: "bold-agency",
        name: "Ember Noir",
        description: "High-impact jet-black canvas with a fiery orange accent. Bold, expressive, unforgettable.",
        themeSelected: "Dark",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "FORMA",
                    links: ["Work", "About", "Process", "Contact"],
                    variant: "Glassy Island",
                    bgColor: "#0a0a0f",
                    textColor: "#ffffff",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "We make brands unforgettable.",
                    subheading: "Award-winning creative studio crafting bold identities, films, and digital experiences that stop people in their tracks.",
                    ctaText: "See Our Work",
                    ctaLink: "#work",
                    variant: "Centered Image Bg",
                    bgColor: "#0a0a0f",
                    textColor: "#ffffff",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                    backgroundImageQuery: "studio",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Selected Projects",
                    items: [
                        { title: "Nike Campaign", description: "Global product launch campaign across 40 markets.", imageQuery: "athlete" },
                        { title: "Luxury Rebrand", description: "Complete visual transformation for a heritage brand.", imageQuery: "luxury" },
                        { title: "Film Direction", description: "Short form content driving 12M+ organic views.", imageQuery: "photography" },
                        { title: "App Design", description: "Fintech app with 4.9-star App Store rating.", imageQuery: "tech" },
                        { title: "Brand System", description: "101-page brand bible for a Series B startup.", imageQuery: "design" },
                        { title: "Retail Space", description: "Immersive pop-up experience for 8,000+ visitors.", imageQuery: "interior" },
                    ],
                    variant: "Bento Grid",
                    bgColor: "#0a0a0f",
                    textColor: "#ffffff",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Strategy meets craft.",
                    description: "Great work starts with deep thinking. We research, question, and push boundaries before a single pixel is placed.",
                    variant: "Card Based",
                    bgColor: "#111118",
                    textColor: "#ffffff",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Got a bold idea?",
                    subheading: "We're selective about who we work with. Let's find out if we're the right fit.",
                    ctaText: "Start a Conversation",
                    ctaLink: "#contact",
                    variant: "Split Screen CTA",
                    bgColor: "#0a0a0f",
                    textColor: "#ffffff",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "ContactForm",
                props: {
                    heading: "Let's Talk",
                    fields: ["name", "email", "company", "budget", "message"],
                    variant: "Centered Card",
                    bgColor: "#0a0a0f",
                    textColor: "#ffffff",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                    submitText: "Send Inquiry",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 FORMA Studio. All rights reserved.",
                    variant: "Ultra Minimal",
                    bgColor: "#050508",
                    textColor: "#52525b",
                    accentColor: "#f97316",
                    fontFamily: "Outfit",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 6. RESTAURANT & FOOD — Warm Cream / Amber Brown
    //    Font: Playfair Display (warm, editorial, rich)
    // ─────────────────────────────────────────────
    {
        id: "local-restaurant",
        name: "Golden Amber",
        description: "Warm cream tones with golden amber accents and a cozy serif. Rich and inviting for any brand.",
        themeSelected: "Light",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "Maison",
                    links: ["Menu", "Reservations", "About", "Contact"],
                    variant: "Full Width Solid",
                    bgColor: "#fef3e2",
                    textColor: "#1c0f00",
                    accentColor: "#b45309",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "Taste the difference.",
                    subheading: "Farm-to-table cuisine crafted daily with seasonal ingredients and decades of culinary passion.",
                    ctaText: "Reserve a Table",
                    ctaLink: "#reservations",
                    variant: "Centered Image Bg",
                    bgColor: "#fef3e2",
                    textColor: "#ffffff",
                    accentColor: "#b45309",
                    fontFamily: "Playfair Display",
                    backgroundImageQuery: "restaurant",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Our Story",
                    description: "Born from a love of authentic flavors and community, Maison has been bringing people together around the table since 2008. Every dish tells a story.",
                    variant: "Left Aligned Big",
                    bgColor: "#fff9f0",
                    textColor: "#1c0f00",
                    accentColor: "#b45309",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Gallery",
                props: {
                    eyebrow: "On the Menu",
                    heading: "Featured Dishes",
                    items: [
                        { title: "Seared Duck Breast", description: "Free-range duck with cherry gastrique and truffle jus.", imageQuery: "gourmet duck plate", price: "$34" },
                        { title: "Truffle Risotto", description: "Aged parmesan and black truffle from the Périgord.", imageQuery: "truffle risotto", price: "$28" },
                        { title: "Catch of the Day", description: "Line-caught fish with seasonal vegetable medley.", imageQuery: "seafood plate", price: "$36" },
                        { title: "Artisan Desserts", description: "Handcrafted pastries by our award-winning pastry chef.", imageQuery: "dessert plating", price: "$14" },
                    ],
                    variant: "Modern Grid",
                    bgColor: "#fef3e2",
                    textColor: "#1c0f00",
                    accentColor: "#b45309",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Join us for an unforgettable evening.",
                    subheading: "Tables fill quickly. Book yours now.",
                    ctaText: "Make a Reservation",
                    ctaLink: "#reservations",
                    variant: "Centered Large",
                    bgColor: "#fff9f0",
                    textColor: "#1c0f00",
                    accentColor: "#b45309",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "ContactForm",
                props: {
                    heading: "Reservations & Enquiries",
                    fields: ["name", "email", "phone", "date", "guests", "message"],
                    variant: "Left Text Right Form",
                    bgColor: "#fef3e2",
                    textColor: "#1c0f00",
                    accentColor: "#b45309",
                    fontFamily: "Playfair Display",
                    submitText: "Request Reservation",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 Maison Restaurant.",
                    variant: "Simple Centered",
                    bgColor: "#1c0f00",
                    textColor: "#a87d4b",
                    accentColor: "#f59e0b",
                    fontFamily: "Playfair Display",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 7. FITNESS & WELLNESS — Deep Black / Neon Lime
    //    Font: Outfit (athletic, energetic)
    // ─────────────────────────────────────────────
    {
        id: "fitness-wellness",
        name: "Charcoal Volt",
        description: "Athletic black theme with an electric lime-green punch. Energetic and high-contrast.",
        themeSelected: "Dark",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "APEX",
                    links: ["Programs", "Coaches", "Schedule", "Join"],
                    variant: "Full Width Solid",
                    bgColor: "#050505",
                    textColor: "#ffffff",
                    accentColor: "#a3e635",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "Transform your body. Master your mind.",
                    subheading:
                        "Elite coaching programs, state-of-the-art facilities, and a community that pushes you to your limit — every single day.",
                    ctaText: "Start Free Trial",
                    ctaLink: "#join",
                    variant: "Centered Image Bg",
                    bgColor: "#050505",
                    textColor: "#ffffff",
                    accentColor: "#a3e635",
                    fontFamily: "Outfit",
                    backgroundImageQuery: "fitness",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Our Programs",
                    items: [
                        { title: "Strength & Power", description: "Progressive overload programming for elite strength gains.", imageQuery: "gym" },
                        { title: "HIIT Cardio", description: "High-intensity intervals that torch calories and build endurance.", imageQuery: "workout" },
                        { title: "Yoga & Mobility", description: "Flexibility, balance, and recovery sessions for all levels.", imageQuery: "yoga" },
                        { title: "Olympic Lifting", description: "Master the snatch and clean & jerk with world-class coaches.", imageQuery: "athlete" },
                        { title: "Nutrition Plan", description: "Personalized meal plans designed for your specific goals.", imageQuery: "food" },
                        { title: "1-on-1 Coaching", description: "Personal trainer sessions tailored entirely to you.", imageQuery: "runner" },
                    ],
                    variant: "Modern Grid",
                    bgColor: "#0a0a0a",
                    textColor: "#ffffff",
                    accentColor: "#a3e635",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Text",
                props: {
                    heading: "Results-driven training.",
                    description: "Our science-based approach combines strength, conditioning, and recovery to deliver measurable results in record time.",
                    variant: "Card Based",
                    bgColor: "#111111",
                    textColor: "#ffffff",
                    accentColor: "#a3e635",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Ready to level up?",
                    subheading: "First 14 days free. No credit card required.",
                    ctaText: "Join Now",
                    ctaLink: "#join",
                    variant: "Floating Pill",
                    bgColor: "#050505",
                    textColor: "#ffffff",
                    accentColor: "#a3e635",
                    fontFamily: "Outfit",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 APEX Performance. All rights reserved.",
                    variant: "Ultra Minimal",
                    bgColor: "#020202",
                    textColor: "#4b5563",
                    accentColor: "#a3e635",
                    fontFamily: "Outfit",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 8. BEAUTY / SPA — Blush Pink / Rose Gold
    //    Font: Playfair Display (soft, luxurious)
    // ─────────────────────────────────────────────
    {
        id: "beauty-spa",
        name: "Blush Rosé",
        description: "Soft blush-pink and rose tones with a delicate, luxurious serif. Elegant and refined.",
        themeSelected: "Light",
        sections: [
            {
                type: "Navbar",
                props: {
                    brand: "Lumière",
                    links: ["Services", "Gallery", "About", "Book"],
                    variant: "Minimal Transparent",
                    bgColor: "#fff5f7",
                    textColor: "#3d1c2e",
                    accentColor: "#be185d",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "Hero",
                props: {
                    heading: "Radiance, redefined.",
                    subheading: "Luxury beauty treatments designed to restore, rejuvenate, and reveal your most confident self.",
                    ctaText: "Book an Appointment",
                    ctaLink: "#book",
                    variant: "Split Text Right",
                    bgColor: "#fff5f7",
                    textColor: "#3d1c2e",
                    accentColor: "#be185d",
                    fontFamily: "Playfair Display",
                    backgroundImageQuery: "beauty",
                },
            },
            {
                type: "Gallery",
                props: {
                    heading: "Our Treatments",
                    items: [
                        { title: "Glow Facial", description: "Deep-cleansing radiance treatment using premium botanicals.", imageQuery: "skincare" },
                        { title: "Hot Stone Massage", description: "90 minutes of deep relaxation with heated volcanic stones.", imageQuery: "spa" },
                        { title: "Lash Extensions", description: "Volume and length tailored to your natural beauty.", imageQuery: "beauty" },
                        { title: "Bridal Package", description: "Complete bridal beauty experience for your special day.", imageQuery: "makeup" },
                        { title: "Body Scrub", description: "Full-body exfoliation leaving skin silky-smooth.", imageQuery: "salon" },
                        { title: "Nail Art", description: "Creative nail art by our award-winning technicians.", imageQuery: "skincare" },
                    ],
                    variant: "Modern Grid",
                    bgColor: "#fff0f4",
                    textColor: "#3d1c2e",
                    accentColor: "#be185d",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "CTA",
                props: {
                    heading: "Your glow awaits.",
                    subheading: "New clients receive 20% off their first visit.",
                    ctaText: "Book Now",
                    ctaLink: "#book",
                    variant: "Centered Large",
                    bgColor: "#fff5f7",
                    textColor: "#3d1c2e",
                    accentColor: "#be185d",
                    fontFamily: "Playfair Display",
                },
            },
            {
                type: "ContactForm",
                props: {
                    heading: "Book Your Visit",
                    fields: ["name", "email", "phone", "service", "date", "message"],
                    variant: "Centered Card",
                    bgColor: "#fff0f4",
                    textColor: "#3d1c2e",
                    accentColor: "#be185d",
                    fontFamily: "Playfair Display",
                    submitText: "Request Booking",
                },
            },
            {
                type: "Footer",
                props: {
                    text: "© 2026 Lumière Beauty Lounge.",
                    variant: "Simple Centered",
                    bgColor: "#3d1c2e",
                    textColor: "#c084a0",
                    accentColor: "#f9a8d4",
                    fontFamily: "Playfair Display",
                },
            },
        ],
    },

    // ─────────────────────────────────────────────
    // 9. FITNESS — EDITORIAL LIGHT ("Move With Meaning")
    //    Off-white + charcoal, lime accent, Playfair serif
    // ─────────────────────────────────────────────
    {
        id: "fitness-editorial",
        name: "Sage Magazine",
        description: "Off-white editorial layout with sage-lime accents and elegant serif headlines.",
        themeSelected: "Light",
        sections: [
            { type: "Navbar", props: { brand: "Sensia", links: ["Overview", "Features", "Technology", "Community"], variant: "Minimal Transparent", bgColor: "#f4f5f0", textColor: "#15170f", accentColor: "#65a30d", fontFamily: "Playfair Display" } },
            { type: "Hero", props: { eyebrow: "AI Wellness Companion", heading: "Move With Meaning", subheading: "Sensia is your AI-driven coach that listens, learns, and adapts — helping your body find its natural rhythm every day.", ctaText: "Start Moving", ctaLink: "#start", variant: "Editorial Centered", bgColor: "#eef0e8", textColor: "#15170f", accentColor: "#65a30d", fontFamily: "Playfair Display", backgroundImageQuery: "athlete running portrait" } },
            { type: "Text", props: { heading: "Fitness That Understands You", description: "Sensia combines the precision of a tracker with the intuition of a coach — helping you move better, eat smarter, and rest deeper. Every plan adapts to how you actually feel.", variant: "Left Aligned Big", bgColor: "#f4f5f0", textColor: "#15170f", accentColor: "#65a30d", fontFamily: "Playfair Display" } },
            { type: "Gallery", props: { heading: "Built Around You", items: [
                { title: "Adaptive Coaching", description: "Plans that learn your patterns and adjust in real time.", imageQuery: "fitness coaching" },
                { title: "Balance Over Burnout", description: "Recovery-first programming that keeps you consistent.", imageQuery: "yoga stretch" },
                { title: "Effortless Connection", description: "Syncs with Apple Watch, Garmin, and Whoop instantly.", imageQuery: "smartwatch fitness" },
                { title: "Real Progress", description: "Track strength, sleep, and energy in one clean view.", imageQuery: "gym workout" },
            ], variant: "Bento Grid", bgColor: "#15170f", textColor: "#f4f5f0", accentColor: "#a3e635", fontFamily: "Playfair Display" } },
            { type: "CTA", props: { heading: "Train smarter, not harder.", subheading: "Join thousands moving with intention every day.", ctaText: "Download the App", ctaLink: "#download", variant: "Split Screen CTA", bgColor: "#65a30d", textColor: "#ffffff", accentColor: "#15170f", fontFamily: "Playfair Display" } },
            { type: "Footer", props: { text: "© 2026 Sensia. Move with meaning.", variant: "Multi-Column Mock", bgColor: "#15170f", textColor: "#8a8f7d", accentColor: "#a3e635", fontFamily: "Playfair Display" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 10. FITNESS — NEON DARK ("Velocity / Run Club")
    //     Near-black, electric lime, Space Grotesk
    // ─────────────────────────────────────────────
    {
        id: "fitness-neon-dark",
        name: "Electric Lime",
        description: "High-energy near-black with neon lime accents and bold geometric type.",
        themeSelected: "Dark",
        sections: [
            { type: "Navbar", props: { brand: "Velocity", links: ["Classes", "Trainers", "Membership", "Shop"], variant: "Glassy Island", bgColor: "#0a0b0a", textColor: "#ffffff", accentColor: "#bef264", fontFamily: "Space Grotesk" } },
            { type: "Hero", props: { heading: "Push Your Limits", subheading: "Train with elite coaches, smart equipment, and a community that shows up. Your strongest self starts now.", ctaText: "Start Free Trial", ctaLink: "#trial", variant: "Split Text Left", bgColor: "#0a0b0a", textColor: "#ffffff", accentColor: "#bef264", fontFamily: "Space Grotesk", backgroundImageQuery: "dark gym workout athlete" } },
            { type: "Gallery", props: { heading: "Train Your Way", items: [
                { title: "Strength Lab", description: "Progressive overload programs that build real power.", imageQuery: "weightlifting gym" },
                { title: "HIIT Studio", description: "45-minute sessions that torch calories fast.", imageQuery: "hiit training" },
                { title: "Endurance", description: "Run-club coaching with live pace tracking.", imageQuery: "runner night" },
                { title: "Mobility", description: "Recovery and flexibility built into every week.", imageQuery: "stretching fitness" },
                { title: "Nutrition", description: "Personalized fuel plans from registered dietitians.", imageQuery: "healthy meal prep" },
                { title: "Community", description: "Leaderboards, challenges, and accountability.", imageQuery: "group fitness class" },
            ], variant: "Bento Grid", bgColor: "#0a0b0a", textColor: "#ffffff", accentColor: "#bef264", fontFamily: "Space Grotesk" } },
            { type: "Text", props: { heading: "Results You Can Measure", description: "Every rep, run, and recovery session is tracked and visualized. See your duration, distance, and heart rate trend up — week after week.", variant: "Card Based", bgColor: "#111311", textColor: "#ffffff", accentColor: "#bef264", fontFamily: "Space Grotesk" } },
            { type: "CTA", props: { heading: "Your first week is on us.", subheading: "No contracts. Cancel anytime.", ctaText: "Claim Your Spot", ctaLink: "#join", variant: "Floating Pill", bgColor: "#0a0b0a", textColor: "#ffffff", accentColor: "#bef264", fontFamily: "Space Grotesk" } },
            { type: "Footer", props: { text: "© 2026 Velocity Club. Move fast.", variant: "Multi-Column Mock", bgColor: "#060706", textColor: "#6b6f66", accentColor: "#bef264", fontFamily: "Space Grotesk" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 11. RESTAURANT — LUXURY DARK ("Savor Luxury / Velora")
    //     Deep espresso + warm gold, Cormorant serif
    // ─────────────────────────────────────────────
    {
        id: "restaurant-luxury",
        name: "Espresso Gold",
        description: "Opulent espresso-and-gold dark theme with a refined serif. Luxurious and dramatic.",
        themeSelected: "Dark",
        sections: [
            { type: "Navbar", props: { brand: "Velora", links: ["Menu", "Bar", "Experience", "Reservations"], variant: "Minimal Transparent", bgColor: "#140f0a", textColor: "#f3e9da", accentColor: "#c9a16b", fontFamily: "Cormorant Garamond" } },
            { type: "Hero", props: { eyebrow: "Fine Dining · Est. 2009", heading: "Savor Luxury", subheading: "An exquisite dining journey where culinary artistry meets world-class cocktails in an atmosphere of timeless elegance.", ctaText: "Reserve a Table", ctaLink: "#reserve", secondaryCtaText: null, variant: "Centered Image Bg", bgColor: "#140f0a", textColor: "#ffffff", accentColor: "#c9a16b", fontFamily: "Cormorant Garamond", backgroundImageQuery: "luxury restaurant bar interior" } },
            { type: "Text", props: { eyebrow: "Our Philosophy", heading: "Where every flavor is elevated by elegance", description: "From the first pour to the final course, every detail is considered. Seasonal ingredients, masterful technique, and a setting designed for unforgettable evenings.", variant: "Left Aligned Big", bgColor: "#f5efe6", textColor: "#2a1d12", accentColor: "#9a6b34", fontFamily: "Cormorant Garamond" } },
            { type: "Gallery", props: { eyebrow: "Best Sellers", heading: "Signature Dishes", items: [
                { title: "Wagyu Risotto", description: "Creamy arborio rice with the earthy aroma of black truffle, tender premium wagyu, and a delicate drizzle of truffle oil.", imageQuery: "wagyu fine dining plate", price: "$48" },
                { title: "Midnight Velvet", description: "Premium vodka blended with fresh espresso and a touch of dark chocolate, finished with a silky foam top.", imageQuery: "espresso martini cocktail", price: "$22" },
                { title: "Velora Steak", description: "Dry-aged ribeye finished over open flame, served with seasonal accompaniments.", imageQuery: "grilled steak gourmet", price: "$64" },
                { title: "Black Truffle Pasta", description: "Hand-shaved truffle over house-made tagliatelle in a silky parmesan emulsion.", imageQuery: "truffle pasta plate", price: "$38" },
            ], variant: "Editorial Showcase", bgColor: "#140f0a", textColor: "#f3e9da", accentColor: "#c9a16b", fontFamily: "Cormorant Garamond" } },
            { type: "ContactForm", props: { heading: "Reserve Your Evening", fields: ["name", "email", "phone", "date", "guests", "message"], variant: "Centered Card", bgColor: "#1c150d", textColor: "#f3e9da", accentColor: "#c9a16b", fontFamily: "Cormorant Garamond", submitText: "Request Reservation" } },
            { type: "Footer", props: { text: "© 2026 Velora. Timeless elegance, every evening.", variant: "Multi-Column Mock", bgColor: "#0d0906", textColor: "#9a8b76", accentColor: "#c9a16b", fontFamily: "Cormorant Garamond" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 12. RESTAURANT — WARM CREAM ("Drizzle")
    //     Cream + terracotta red, Playfair serif
    // ─────────────────────────────────────────────
    {
        id: "restaurant-warm",
        name: "Terracotta Cream",
        description: "Cozy cream canvas with warm terracotta accents and an elegant serif. Heritage-inspired.",
        themeSelected: "Light",
        sections: [
            { type: "Navbar", props: { brand: "Drizzle", links: ["Menu", "About", "Gallery", "Reservations"], variant: "Minimal Transparent", bgColor: "#f7f1e3", textColor: "#3a1e18", accentColor: "#b1402f", fontFamily: "Playfair Display" } },
            { type: "Hero", props: { eyebrow: "Made with Love, Served with Joy", heading: "Experience the Language of Taste", subheading: "Blending tradition and innovation to create unforgettable dining experiences.", ctaText: "Reserve a Table", ctaLink: "#reserve", variant: "Editorial Centered", bgColor: "#f7f1e3", textColor: "#3a1e18", accentColor: "#b1402f", fontFamily: "Playfair Display", backgroundImageQuery: "warm restaurant interior dining" } },
            { type: "Text", props: { eyebrow: "Know About Us", heading: "Blending tradition & innovation", description: "Every dish tells a story of heritage and craft. Our chefs source the freshest seasonal ingredients to create plates that feel both familiar and exciting.", variant: "Left Aligned Big", bgColor: "#fdf8ee", textColor: "#3a1e18", accentColor: "#b1402f", fontFamily: "Playfair Display" } },
            { type: "Gallery", props: { eyebrow: "A Feast for the Eyes", heading: "Taste the vibes through our gallery", items: [
                { title: "Seafood Delights", description: "Fresh catches prepared with bold, bright flavors.", imageQuery: "seafood plate gourmet" },
                { title: "Pasta & Risotto", description: "Hand-made pasta with rich, slow-cooked sauces.", imageQuery: "pasta dish restaurant" },
                { title: "Fresh Salads", description: "Light, healthy, and packed with garden flavor.", imageQuery: "fresh salad bowl" },
                { title: "Wood-Fired", description: "Colorful creations inspired by nature.", imageQuery: "wood fired pizza" },
                { title: "Craft Drinks", description: "Sip, savor, and refresh your senses.", imageQuery: "craft cocktails drinks" },
                { title: "Desserts", description: "Sweet endings worth saving room for.", imageQuery: "dessert plating restaurant" },
            ], variant: "Polaroid Strip", bgColor: "#fdf8ee", textColor: "#3a1e18", accentColor: "#b1402f", fontFamily: "Playfair Display" } },
            { type: "CTA", props: { heading: "Where every visit becomes a memory.", subheading: "Reserve your spot — the ultimate joy of dining done right.", ctaText: "Reserve Your Table", ctaLink: "#reserve", variant: "Split Screen CTA", bgColor: "#b1402f", textColor: "#fdf8ee", accentColor: "#3a1e18", fontFamily: "Playfair Display" } },
            { type: "Footer", props: { text: "© 2026 Drizzle. Made with love, served with joy.", variant: "Multi-Column Mock", bgColor: "#3a1e18", textColor: "#c8a99a", accentColor: "#e9b949", fontFamily: "Playfair Display" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 13. CLOTHING — MINIMAL EDITORIAL ("Almina / Nextgen")
    //     Off-white + ink black, Archivo / Outfit
    // ─────────────────────────────────────────────
    {
        id: "clothing-minimal",
        name: "Gallery Mono",
        description: "Minimalist off-white gallery layout with bold sans type and neutral tones.",
        themeSelected: "Light",
        sections: [
            { type: "Navbar", props: { brand: "ALMINA", links: ["Shop", "Lookbook", "Our Story", "Contact"], variant: "Minimal Transparent", bgColor: "#f2f0ec", textColor: "#0e0e0e", accentColor: "#0e0e0e", fontFamily: "Archivo" } },
            { type: "Hero", props: { heading: "Our Latest Offerings", subheading: "Discover a curated collection of fashion designed to suit your unique style — cutting-edge design and premium quality for every occasion.", ctaText: "Explore Product", ctaLink: "#shop", variant: "Centered Image Bg", bgColor: "#e8e6e1", textColor: "#0e0e0e", accentColor: "#0e0e0e", fontFamily: "Archivo", backgroundImageQuery: "fashion editorial model studio" } },
            { type: "Gallery", props: { eyebrow: "Our Product", heading: "Browse the Collection", items: [
                { title: "Oversized Blazer", description: "Tailored structure in premium tencel.", imageQuery: "fashion blazer model", price: "$240" },
                { title: "Zip-Up Knit", description: "Soft merino blend for everyday layering.", imageQuery: "knitwear fashion", price: "$180" },
                { title: "Linen Shirt", description: "Breathable, relaxed, effortlessly refined.", imageQuery: "linen shirt fashion", price: "$120" },
                { title: "Wide Trousers", description: "Fluid drape with a clean high waist.", imageQuery: "trousers fashion model", price: "$160" },
                { title: "Wool Coat", description: "A timeless silhouette for cooler days.", imageQuery: "wool coat fashion", price: "$360" },
                { title: "Essential Tee", description: "The perfect heavyweight cotton basic.", imageQuery: "tshirt fashion minimal", price: "$60" },
            ], variant: "Modern Grid", bgColor: "#f2f0ec", textColor: "#0e0e0e", accentColor: "#0e0e0e", fontFamily: "Archivo" } },
            { type: "Text", props: { heading: "Where dreams meet couture", description: "We design enduring pieces meant to be worn, loved, and kept. Considered materials, honest construction, and a quiet confidence in every stitch.", variant: "Left Aligned Big", bgColor: "#e8e6e1", textColor: "#0e0e0e", accentColor: "#0e0e0e", fontFamily: "Archivo" } },
            { type: "CTA", props: { heading: "Summer arrival is here.", subheading: "Sign up and get 20% off your first order.", ctaText: "Shop Now", ctaLink: "#shop", variant: "Centered Large", bgColor: "#0e0e0e", textColor: "#ffffff", accentColor: "#d8c3a5", fontFamily: "Archivo" } },
            { type: "Footer", props: { text: "© 2026 ALMINA Concept.", variant: "Multi-Column Mock", bgColor: "#0e0e0e", textColor: "#8a8a8a", accentColor: "#ffffff", fontFamily: "Archivo" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 14. CLOTHING — STREET DARK
    //     Charcoal + acid accent, Space Grotesk
    // ─────────────────────────────────────────────
    {
        id: "clothing-street",
        name: "Acid Street",
        description: "Confident charcoal theme with an acid-yellow accent and bold geometric type.",
        themeSelected: "Dark",
        sections: [
            { type: "Navbar", props: { brand: "NEXTGEN", links: ["Men", "Women", "Drops", "About"], variant: "Glassy Island", bgColor: "#0c0c0d", textColor: "#ffffff", accentColor: "#e2ff54", fontFamily: "Space Grotesk" } },
            { type: "Hero", props: { heading: "Wear the Future", subheading: "Limited drops, premium fabrics, and silhouettes built for the street. Quality fashion that reflects your style.", ctaText: "Shop the Drop", ctaLink: "#shop", variant: "Split Text Right", bgColor: "#0c0c0d", textColor: "#ffffff", accentColor: "#e2ff54", fontFamily: "Space Grotesk", backgroundImageQuery: "streetwear fashion model dark" } },
            { type: "Gallery", props: { eyebrow: "New Arrivals", heading: "This Season's Drop", items: [
                { title: "Tech Cargo", description: "Utility-driven cargos in water-repellent shell.", imageQuery: "cargo pants streetwear", price: "$140" },
                { title: "Boxy Hoodie", description: "Heavyweight fleece with a relaxed cut.", imageQuery: "hoodie streetwear", price: "$110" },
                { title: "Graphic Tee", description: "Screen-printed art on organic cotton.", imageQuery: "graphic tshirt fashion", price: "$55" },
                { title: "Shell Jacket", description: "Lightweight, packable, all-weather ready.", imageQuery: "jacket fashion model", price: "$220" },
                { title: "Knit Beanie", description: "Ribbed merino for cold-weather edge.", imageQuery: "beanie streetwear", price: "$35" },
                { title: "Chunky Sneaker", description: "Sculpted sole, premium leather upper.", imageQuery: "sneakers fashion", price: "$190" },
            ], variant: "Modern Grid", bgColor: "#0c0c0d", textColor: "#ffffff", accentColor: "#e2ff54", fontFamily: "Space Grotesk" } },
            { type: "CTA", props: { heading: "Don't sleep on the next drop.", subheading: "Subscribe for early access and member-only releases.", ctaText: "Get Early Access", ctaLink: "#join", variant: "Floating Pill", bgColor: "#0c0c0d", textColor: "#ffffff", accentColor: "#e2ff54", fontFamily: "Space Grotesk" } },
            { type: "Footer", props: { text: "© 2026 NEXTGEN. Worn forward.", variant: "Multi-Column Mock", bgColor: "#070708", textColor: "#6f6f74", accentColor: "#e2ff54", fontFamily: "Space Grotesk" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 15. CORPORATE — TRUST BLUE ("ECI / ROV")
    //     White + navy, Outfit
    // ─────────────────────────────────────────────
    {
        id: "corporate-trust",
        name: "Navy Trust",
        description: "Crisp white-and-navy palette — confident, clean, and trustworthy.",
        themeSelected: "Light",
        sections: [
            { type: "Navbar", props: { brand: "ECI", links: ["About", "Services", "Team", "News"], variant: "Full Width Solid", bgColor: "#ffffff", textColor: "#0f2747", accentColor: "#2563eb", fontFamily: "Outfit" } },
            { type: "Hero", props: { eyebrow: "Innovation & Integrity", heading: "Secure Tomorrow With Confidence", subheading: "Protecting your future with tailored solutions and a forward-thinking approach — built on integrity, expertise, and trust.", ctaText: "Get Started", ctaLink: "#contact", socialProof: "Trusted by 200+ enterprises worldwide", variant: "Split Text Left", bgColor: "#eef3fb", textColor: "#0f2747", accentColor: "#2563eb", fontFamily: "Outfit", backgroundImageQuery: "modern corporate architecture building" } },
            { type: "Text", props: { heading: "Protecting Futures, Empowering Progress", description: "For over two decades we've been a trusted partner for businesses and families worldwide. We design smart solutions that help you plan with clarity and act with confidence.", variant: "Card Based", bgColor: "#ffffff", textColor: "#0f2747", accentColor: "#2563eb", fontFamily: "Outfit" } },
            { type: "Gallery", props: { heading: "The Foundation of Our Commitment", items: [
                { title: "Strength & Reliability", description: "Decades of expertise and a record clients depend on.", imageQuery: "corporate handshake business" },
                { title: "Integrity & Transparency", description: "The highest ethical standards in everything we do.", imageQuery: "business meeting office" },
                { title: "Client First", description: "Tailored guidance built entirely around your goals.", imageQuery: "professional consulting" },
                { title: "Sustainable Growth", description: "Solutions designed for the long term, not the moment.", imageQuery: "city skyline business" },
            ], variant: "Modern Grid", bgColor: "#f4f7fc", textColor: "#0f2747", accentColor: "#2563eb", fontFamily: "Outfit" } },
            { type: "CTA", props: { heading: "Ready to secure your future?", subheading: "Whether protecting your family or your business, we're here to help.", ctaText: "Talk to an Expert", ctaLink: "#contact", variant: "Dark Banner", bgColor: "#0f2747", textColor: "#ffffff", accentColor: "#60a5fa", fontFamily: "Outfit" } },
            { type: "Footer", props: { text: "© 2026 ECI Corporate. Innovation & integrity.", variant: "Multi-Column Mock", bgColor: "#0a1c33", textColor: "#7e93ab", accentColor: "#60a5fa", fontFamily: "Outfit" } },
        ],
    },

    // ─────────────────────────────────────────────
    // 16. SAAS — HEALTHCARE / ELEGANT ("Livera")
    //     Soft blue gradient, Outfit
    // ─────────────────────────────────────────────
    {
        id: "saas-healthcare",
        name: "Soft Azure",
        description: "Calm, airy soft-blue gradients with plenty of whitespace. Clean and premium.",
        themeSelected: "Light",
        sections: [
            { type: "Navbar", props: { brand: "Livera", links: ["Features", "Solutions", "Resources", "Pricing"], variant: "Glassy Island", bgColor: "#eef2fb", textColor: "#10203a", accentColor: "#3b6ef5", fontFamily: "Outfit" } },
            { type: "Hero", props: { heading: "The intelligence layer for digital clinics", subheading: "Livera helps modern healthcare providers operate safer, faster, and more compliantly — without sacrificing clinical quality or scale.", ctaText: "Book a Private Demo", ctaLink: "#demo", variant: "Centered Image Bg", bgColor: "#e7eefb", textColor: "#10203a", accentColor: "#3b6ef5", fontFamily: "Outfit", backgroundImageQuery: "abstract blue flowing waves" } },
            { type: "Text", props: { heading: "Built for outcomes, not overhead", description: "Digital clinics don't compete on marketing — they compete on infrastructure. Livera gives you the operating system to scale care with confidence.", variant: "Left Aligned Big", bgColor: "#ffffff", textColor: "#10203a", accentColor: "#3b6ef5", fontFamily: "Outfit" } },
            { type: "Gallery", props: { heading: "Everything your clinic needs", items: [
                { title: "Smart Scheduling", description: "AI-optimized booking that cuts no-shows in half.", imageQuery: "healthcare technology" },
                { title: "Compliance Engine", description: "HIPAA-ready workflows baked into every action.", imageQuery: "medical data security" },
                { title: "Patient Portal", description: "A calm, modern experience patients actually love.", imageQuery: "patient app healthcare" },
                { title: "Care Analytics", description: "Real-time dashboards across every location.", imageQuery: "medical dashboard analytics" },
                { title: "Secure Messaging", description: "Encrypted communication for teams and patients.", imageQuery: "doctor laptop clinic" },
                { title: "Integrations", description: "Connect your EHR, billing, and labs in minutes.", imageQuery: "modern clinic technology" },
            ], variant: "Bento Grid", bgColor: "#eef2fb", textColor: "#10203a", accentColor: "#3b6ef5", fontFamily: "Outfit" } },
            { type: "CTA", props: { heading: "See Livera in your workflow.", subheading: "Private demos for founding clinics now open.", ctaText: "Book a Private Demo", ctaLink: "#demo", variant: "Floating Pill", bgColor: "#10203a", textColor: "#ffffff", accentColor: "#7aa2ff", fontFamily: "Outfit" } },
            { type: "Footer", props: { text: "© 2026 Livera. Intelligence for modern care.", variant: "Multi-Column Mock", bgColor: "#0a1526", textColor: "#7388a8", accentColor: "#7aa2ff", fontFamily: "Outfit" } },
        ],
    },
];
